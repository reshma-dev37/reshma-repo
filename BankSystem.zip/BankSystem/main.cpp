#include<iostream>
using namespace std;

#include"inc/BankAccount.h"
#include"inc/Bank.h"

int main()
{
    int choice;
    double amount;
    int accountNumber;
    Bank B;
    while(true)
    {
        cout<<"Main Bank Application Menu:"<<endl;
        cout<<"1. Create Account "<<endl;
        cout<<"2. Deposit money"<<endl;
        cout<<"3. Withdraw money:"<<endl;
        cout << "4. Display Account Details\n";
        cout<<"5.Close account"<<endl;
        cout << "6. Display All Accounts\n";
        cout<<"7.Exit"<<endl;
        cout<<"Enter your choice :"<<endl;
        cin>>choice;

        switch(choice)
        {
            case 1:
                 B.createAccount();
                 break;
            case 2:
                cout<<"Enter Account Number"<<endl;
                cin>>accountNumber;
                cout<<"Enter amount to deposit"<<endl;
                cin>>amount;
                B.depositToAccount(accountNumber,amount);
            break;
            case 3:
                cout<<"Enter account Number"<<endl;
                cin>>accountNumber;
                cout<<"Enter amount to deposit "<<endl;
                cin>>amount;
                B.withdrawalFromAccount(accountNumber,amount);
                 break;
            case 4:
                 cout<<"Enter account Number:"<<endl;
                 cin>>accountNumber;
                 B.searchAccount(accountNumber);
                 break;
            case 5:
                cout<<"Enter account Number:"<<endl;
                cin>>accountNumber;
                B.deleteAccount(accountNumber);
                break;
            case 6:
                 B.displayAllAccounts();
                 break;
            case 7:
                 cout<<"Exiting!!!!!...."<<endl;
                 return 0;
            default:
                cout<<"Invalid choice:"<<endl;

        }

    }
}