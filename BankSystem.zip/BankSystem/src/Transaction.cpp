#include<iostream>
#include "../inc/Transaction.h"
using namespace std;

Transaction ::Transaction(int acNo,string type,string date,double a)
{
    accountNumber=acNo;
    this->type =type;
    amount =a;
    this->date =date;
}
void Transaction::displayTransactions() const
{
    cout<<"AccountNumber:"<<accountNumber<<" "<<"Transaction type is:"<<type<<" "<<"Start date is:"<<date<<" "<<"Amount is:"<<endl;
}

    