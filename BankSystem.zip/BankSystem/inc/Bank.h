#ifndef BANK_H
#define BANK_H

#include"../inc/BankAccount.h"
class Bank
{
    std::vector<BankAccount> accounts;
    public:
    void createAccount();
    void deleteAccount(int accountNumber);
    void searchAccount(int accountNumber);
    void depositToAccount(int accountNumber,double amount);
    void withdrawalFromAccount(int accountNumber,double amount);
    void displayAllAccounts();

};
#endif
