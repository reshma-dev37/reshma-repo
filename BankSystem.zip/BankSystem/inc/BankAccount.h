#ifndef BANK_ACCOUNT_H
#define BANK_ACCOUNT_H

#include<string>

class BankAccount
{
private :
    std::string accountHolderName;
    int accountNumber;
    double balance;
    std::string accountType;

public:

    BankAccount();
    BankAccount(std::string name,int accNo,std::string type,double initialBalance);
    void deposit(double amount);
    bool withdraw(double amount);
    double getBalance() const;
    int getAccountNumber() const;
    void displayAccountDetails() const;
};
 #endif 