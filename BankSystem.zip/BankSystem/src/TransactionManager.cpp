#include<iostream>
using namespace std;

#include "../inc/TransactionManager.h"
void TransactionManager::addTransaction()
{
   cout<<"Enter account Number , type of transaction, amount and start date"<<endl;
   int accountNumber;
   cin>>accountNumber;
   string type;
   cin>>type;
   double amount;
   cin>>amount;
   string date;
   cin>>date;

   Transaction t(accountNumber,type,date,amount);

   transactions.push_back(t);
   cout<<"Transaction is added succesfully"<<endl;
}
void TransactionManager::showAllTransactions()
{
    if(transactions.empty())
    {
        cout<<"No transactions available"<<endl;
        return;
    }
    cout<<"All Transactions!!!...."<<endl;
    for(auto &t:transactions)
    {
        t.displayTransactions();
        cout<<"---------------";
    }
}