#ifndef TRANSACTIONMANAGER_H
#define TRANSACTIONMANAGER_H

#include "../inc/Transaction.h"
class TransactionManager
{
    private:
    vector<Transaction>transactions;
    public:
    void addTransaction();
    void showAllTransactions();

};
#endif