#include<iostream>
#include"../inc/BankAccount.h"
using namespace std;

BankAccount ::BankAccount()
{
    accountHolderName ="Unknown";
    accountNumber =1234;
    balance= 0.0;
    accountType = "unknown";
}
    
BankAccount ::BankAccount(std::string name,int acNo,std::string type,double initialBalance)
{
    accountHolderName = name;
        accountNumber=acNo;
        accountType =type;
        balance = initialBalance;
}
void BankAccount ::deposit(double amount)
{
        if(amount<=0)
        {
            cout<<"Invalid amount :"<<endl;
            return;
        }
        balance+=amount;
        cout<<"After deposit available balance is:"<<balance<<endl;
        
}
bool BankAccount ::withdraw(double amount)
{
    if(amount<=0 || balance<amount)
    {
        cout<<"Insufficient amount : please enter valid amount"<<endl;
        return false;
    }
    {
    balance-=amount;
    cout<<"After withdrawal available balance is:"<<endl;
    return true;
    }
    }
double BankAccount ::getBalance() const
{
    return balance;
}
void BankAccount ::displayAccountDetails() const
{
        cout<<"\n Account details are"<<endl;
        cout<<"AccountHolder Name "<<accountHolderName<<endl;
        cout<<"Account Number: "<<accountNumber<<endl;
        cout<<"Type of account is: "<<accountType<<endl;
        cout<<"Balance is: "<<balance<<endl;
}
int BankAccount::getAccountNumber() const
{
     return accountNumber;
}
