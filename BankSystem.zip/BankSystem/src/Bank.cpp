#include<iostream>
#include<vector>
#include<algorithm>
#include "../inc/Bank.h"
using namespace std;

void Bank::createAccount()
{
    string accountHolderName;
    int accountNumber;
    string accountType;
    double initialBalance;
    cout<<"Enter name and account Number:"<<endl;
     getline(cin, accountHolderName);
    cin>>accountNumber;
    cout<<"Type of Account"<<endl;
    cin>>accountType;
    cout<<"Initial Balance when new account is opened"<<endl;
    cin>>initialBalance;
        
    BankAccount BA(accountHolderName,accountNumber,accountType,initialBalance);
        
    accounts.push_back(BA);
    cout<<"New account details are added:"<<endl;
}
    
void Bank ::deleteAccount(int accountNumber)
{
    for(int i=0;i<accounts.size();i++)
    {   
        if(accounts[i].getAccountNumber()==accountNumber)
        {
            accounts.erase(accounts.begin()+i);
            cout<<"Account is deleted"<<endl;
            return;
        }
    }
    cout<<"Account Number is not found"<<endl;
}

void Bank::searchAccount(int accountNumber)
{
    for (auto &acc : accounts)
    {
        if (acc.getAccountNumber() == accountNumber)
        {
            acc.displayAccountDetails();
            return;
        }
    }
    cout << "Account not found\n";
}

void Bank::depositToAccount(int accountNumber,double amount)
{
    for (auto &acc : accounts)
    {
        if (acc.getAccountNumber() == accountNumber)
        {
            acc.deposit(amount);
            return;
        }
    }
    cout<<"Account Not Found:"<<endl;

}

void Bank::withdrawalFromAccount(int accountNumber,double amount)
{
    for (auto &acc : accounts)
    {
        if (acc.getAccountNumber() == accountNumber)
        {
            acc.withdraw(amount);
            return;
        }

    }
     cout<<"Account Not Found:"<<endl;

}

void Bank::displayAllAccounts()
{
   if(accounts.empty())
   {
    cout<<"No account is available:"<<endl;
    return;
   }
   for(auto &acc: accounts)
   {
        acc.displayAccountDetails();
        cout<<"--------------------"<<endl;

   }
}

    