#ifndef TRANSACTION_H
#define TRANSACTION_H

#include<string>

class Transaction
{
    private:

    int accountNumber;
    std::string type;
    double amount;
    std::string date;
    
    public:
    Transaction(int acNo,std::string type,std::string date,double a);
    void displayTransactions() const;
};
#endif